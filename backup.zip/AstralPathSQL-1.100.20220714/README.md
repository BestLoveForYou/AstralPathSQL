# AstralPathSQL
   By BestLoveForYou   
      website:[website](http://www.godserver.cn/)   
      email:yaoboyulove@163.com

# Brief Introduction:
  This is a database system, completely based on java!
At present, balanced binary tree is used in data structure, and its unique data storage structure makes it still competent in the face of a large amount of data

# Usage
**Server**:Download /Server/AstralPathSQL.jar  
launch it: java -jar AstralPathSQL.jar   

**Client**:Download /Client/AstralPathSQL.jar
launch it in a same way

# Config
The config of it (info.properties) include port , all_connect , and change_time   
You can change the config (such as the port) to change application's port .Of course, you should do it after stop this application

# Update records
# v1.000 series
   ## v1.000.20220711   
   This is the original version, which provides binary tree and basic functions
   
   ## v1.000.20220713
   Added cache function to improve query speed
  
# v1.100 series
    Epic update!!!  
         Change the syntax to SQL syntax! Compatible with some SQL languages Others are being manufactured    
         More support!!!   
## v1.000.20220713 Date:2022-07-14   
                     

