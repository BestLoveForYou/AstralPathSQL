# AstralPathSQL
   By BestLoveForYou   
      website:[website](http://www.godserver.cn/)   
      email:yaoboyulove@163.com

# Brief Introduction:
  This is a database system, completely based on java!
At present, balanced binary tree is used in data structure, and its unique data storage structure makes it still competent in the face of a large amount of data

# Usage
**Server**:Download /AstralPathSQL/out/artifacts/AstralPathSQLServer_jar/AstralPathSQL.jar  
launch it: java -jar AstralPathSQL.jar   

**Client**:Download /AstralPathSQL/out/artifacts/AstralPathSQL_jar/AstralPathSQL.jar
launch it in a same way

# Config
The config of it (info.properties) include port , all_connect , and change_time   
You can change the config (such as the port) to change application's port .Of course, you should do it after stop this application

# Update records
# v1.000 series
   ## v1.000.20220711   
   - This is the original version, which provides binary tree and basic functions
   
   ## v1.000.20220713
   - Added cache function to improve query speed
  
# v1.100 series
 - Epic update!!!  
  Change the syntax to SQL syntax! Compatible with some SQL languages Others are being manufactured    
  More support!!!   
 ## v1.100.20220714 Date:2022-07-14   
 ## v1.101.20220714   
Fixed known bugs, including the creation and use of data tables, SQL syntax, etc
 ## v1.102.20220714   
- New functions are available! Users need to log in to connect. The default login account and password are root:123456, and the format needs to be
Account Name: password.
- Fixed several known bugs, including data table deletion, user deletion and reading, etc

 ## 1.103.20220715
 - Several known bugs have been fixed. The biggest bugs are the execution of update and incomplete data

